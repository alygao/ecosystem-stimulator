/*
 * Animal
 * The super class that represents an Animal that can be placed in the ecosystem. It could be a Wolf, a MaleSheep, or a FemaleSheep.
 * @author Alyssa Gao
 * May 3, 2018
 */

public abstract class Animal extends Organism {
  
  // ===================== VARIABLES ===================== 
  
  /**
   * Number of health to lose per each turn, default to 1.
   */
  public static int healthLostEachTurn = 1;
  
  /**
   * Indicates whether the animal has already been moved in a turn. It is set by the EcoSystem.runEcoSystem() when it is moved (including eating, colliding), and reset at the beginning of each turn.   
   */
  private boolean alreadyMovedInTheCurrentTurn = false;
  
  // ===================== CONSTRUCTORS =====================
  
  /**
   * The constructor of an Animal object.
   * @param health the initial health of the Animal to be created.
   */
  public Animal(int health) {
    super(health);
  }
  
  /**
   * The constructor of an Animal object.
   * @param health the initial health of the Animal to be created.
   * @param setNewSpawnAge indicates whether or not to set the newSpawnAge to 3 (instead of 0 as the default value) through the Organism class' constructor. 
   */
  public Animal(int health, boolean setNewSpawnAge) {
    super(health, setNewSpawnAge);
  }
  
  //  ===================== METHODS =====================
  
  /**
   * eat
   * The "eat" function that is expected to be implemented in subclasses (i.e., Wolf, MaleSheep, FemaleSheep).
   * @param organism the Organism that to be eaten.
   */
  public abstract void eat(Organism organism);
  
  /**
   * collide
   * The "collide" function that is expected to be implemented in subclasses (i.e., Wolf, MaleSheep, FemaleSheep).
   * @param animal the Animal with which it collides.
   * @return the new Animal that might be spawn during the collision.  
   */
  public abstract Animal collide(Animal animal);
  
  /**
   * isAlreadyMovedInTheCurrentTurn
   * Returns whether the Animal has already been moved in the current turn.
   * @return true if the Animal has already been moved in the current turn.
   */
  public boolean isAlreadyMovedInTheCurrentTurn() {
    return alreadyMovedInTheCurrentTurn;
  }
  
  /**
   * setAlreadyMovedInTheCurrentTurn
   * Set the alreadyMovedInTheCurrentTurn flag.
   * @param alreadyMovedInTheCurrentTurn set to true to indicate that the Animal has already been moved in the current turn. 
   */
  public void setAlreadyMovedInTheCurrentTurn(boolean alreadyMovedInTheCurrentTurn) {
    this.alreadyMovedInTheCurrentTurn = alreadyMovedInTheCurrentTurn;
  }
}