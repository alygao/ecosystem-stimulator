/*
 * MaleWolf
 * The concrete class that represents a male Wolf that can be placed in the ecosystem.
 * @author Alyssa Gao
 * May 3, 2018
 */

import java.awt.Image;
import java.awt.Toolkit;

public class MaleWolf extends Wolf {
  
  // ===================== VARIABLES ===================== 
  
  /**
   * The filename of the male wolf image.
   */
  public static String maleWolfImageFilename = "male wolf.png";
  
  /**
   * The Image object of the male wolf image.
   */
  public static Image maleWolfImage = Toolkit.getDefaultToolkit().getImage(maleWolfImageFilename);
  
  // ===================== CONSTRUCTORS =====================
  
  /**
   * The constructor of a MaleWolf object.
   * @param health the initial health of the MaleWolf to be created.
   */
  public MaleWolf(int health) {
    super(health);
  }
  
  /**
   * The constructor of a MaleWolf object.
   * @param health the initial health of the MaleWolf to be created.
   * @param setNewSpawnAge indicates whether or not to set the newSpawnAge to 3 (instead of 0 as the default value) through the constructor of the Wolf class, the Animal class and the Organism class.
   */
  public MaleWolf(int health, boolean setNewSpawnAge) {
    super(health, setNewSpawnAge);
  }
  
  //  ===================== METHODS =====================
  
  /**
   * getGenderVersionImage
   * @return maleWolfImage, the graphic image for a male wolf
   */
  public Image getGenderVersionImage () {
     return maleWolfImage;        
  }  
}