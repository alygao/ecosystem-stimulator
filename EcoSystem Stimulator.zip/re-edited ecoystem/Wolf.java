/*
 * Wolf
 * The concrete class that represents a Wolf that can be placed in the ecosystem. It could be either a Male Wolf or a Female Wolf.
 * @author Alyssa Gao
 * May 3, 2018
 */

import java.awt.Image;
import java.awt.Toolkit;

public abstract class Wolf extends Animal implements Comparable<Wolf> {
  
  // ===================== VARIABLES ===================== 
  
  /**
   * The initial health of a new spawn wolf. It is not used for wolf that is initially placed in the ecosystem at the very beginning. 
   */
  public static int spawnHealth; 
  
  /**
   * The filename of the baby wolf image.
   */
  public static String babyWolfFilename = "baby wolf.png";
  
  /**
   * The Image object of the baby wolf image.
   */
  public static Image babyWolfImage = Toolkit.getDefaultToolkit().getImage(babyWolfFilename);
  
  // ===================== CONSTRUCTORS =====================
  
  /**
   * The constructor of a Wolf object.
   * @param health the initial health of the Wolf to be created.
   */
  public Wolf(int health) {
    super(health);
  }
  
  /**
   * The constructor of a Wolf object.
   * @param health the initial health of the Wolf to be created.
   * @param setNewSpawnAge indicates whether or not to set the newSpawnAge to 3 (instead of 0 as the default value) through the constructor of the Animal class and the Organism class.
   */
  public Wolf(int health, boolean setNewSpawnAge) {
    super(health, setNewSpawnAge);
  }
  
  //  ===================== METHODS =====================
  
  /**
   * eat
   * The implementation of the "eat" function for wolves. It is functioning only if the organism is a Sheep.
   * @param organism the organism to be eaten by the wolf, if the organism is only a Sheep. Otherwise, it will not perform any "eat" logic.
   */
  @Override
  public void eat(Organism organism) {
    if ( organism instanceof Sheep ) {
      Sheep sheep = (Sheep) organism;
      setHealth( getHealth() + sheep.getHealth() );
      sheep.setHealth(0);
    }
  }
  
  /**
   * collide
   * The implementation of the "collide" function. It is functioning only if the animal is a Wolf.
   * If the two wolves are the same gender: 
   *     - The weaker wolf loses 10 health points. 
   * If the two wolves are opposite gender:
   *     - It functions if both sheep have the current health equals to or is greater than the half of the spawnHealth.
   *     - Both wolves will lose half of the initial wolf spawn health
   *     - A new MaleWolf or FemaleWolf will be created (with equal chances) with a spawnHealth value. 
   * If the animal is other than a Wolf object, it will not perform any "collide" logic.
   * @param animal the animal to collide with, if the animal is a Wolf object. 
   */
  public Wolf collide(Animal animal) {
    if ( animal instanceof Wolf ) {
      if ( ( this instanceof MaleWolf && animal instanceof FemaleWolf ) ||
          ( this instanceof FemaleWolf && animal instanceof MaleWolf ) ) {
        // If wolves have different genders
        Wolf theOtherWolf = (Wolf) animal;
        if ( this.getHealth() >= spawnHealth && theOtherWolf.getHealth() >= spawnHealth ) {
          this.setHealth(getHealth() - spawnHealth/2);
          theOtherWolf.setHealth(theOtherWolf.getHealth() - spawnHealth/2);
          if ( Math.random() < 0.5 ) {
            return new MaleWolf ( spawnHealth + 1, true );
          } else {
            return new FemaleWolf ( spawnHealth + 1, true );
          }
        }
      } else {
        // If both wolves have the same gender
        Wolf theOtherWolf = (Wolf) animal;
        if ( this.compareTo(theOtherWolf) < 0 ) {
          this.setHealth(getHealth() - 10);
        }else{
          theOtherWolf.setHealth( theOtherWolf.getHealth() - 10);
        }          
      }
    }
    return null;
  }
  
  /**
   * compareTo
   * Compares this wolf with the specified wolf based on the health value.
   * @param theOtherWolf the wolf object to be compared.
   * @return a negative integer, zero, or a positive integer as this Wolf object is less than, equal to, or greater than the specified Wolf object.
   */
  public int compareTo(Wolf theOtherWolf) {
    return this.getHealth() - theOtherWolf.getHealth();
  }
  
  /**
   * getImage
   * The image to be returned by Wolf's subclasses, i.e., MaleWolf or FemaleWolf, that is required by the 
   * draw() method to draw on the Grid.
   * @return Image the image that will be drawn on the Grid
   */
  public Image getImage() {
    if ( getNewSpawnAge() > 0 ) {
      return babyWolfImage;
    }else{
      return getGenderVersionImage ( );        
    }
  }
  
  public abstract Image getGenderVersionImage ( );
}