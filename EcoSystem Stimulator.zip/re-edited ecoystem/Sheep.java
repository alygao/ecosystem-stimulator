/*
 * Sheep
 * The super class that represents a Sheep that can be placed in the ecosystem. It could be either a Male Sheep or a Female Sheep.
 * @author Alyssa Gao
 * May 3, 2018
 */
import java.awt.Image;
import java.awt.Toolkit;

public abstract class Sheep extends Animal {
  
  // ===================== VARIABLES ===================== 
  
  /**
   * The initial health of a new spawn sheep. It is not used for sheep that is initially placed in the ecosystem at the very beginning. 
   */
  public static int spawnHealth;
  
  /**
   * The filename of the baby sheep image.
   */
  public static String babySheepFilename = "baby sheep.png";
  
  /**
   * The Image object of the baby sheep image.
   */
  public static Image babySheepImage = Toolkit.getDefaultToolkit().getImage(babySheepFilename);
  
  // ===================== CONSTRUCTORS =====================
  
  /**
   * The constructor of a Sheep object.
   * @param health the initial health of the Sheep to be created.
   */
  public Sheep(int health) {
    super(health);
  }
  
  /**
   * The constructor of a Sheep object.
   * @param health the initial health of the Sheep to be created.
   * @param setNewSpawnAge indicates whether or not to set the newSpawnAge to 3 (instead of 0 as the default value) through the constructor of the Animal class and the Organism class.
   */
  public Sheep(int health, boolean setNewSpawnAge) {
    super(health, setNewSpawnAge);
  }
  
  //  ===================== METHODS =====================
  
  /**
   * eat
   * The implementation of the "eat" function. It is functioning only if the organism is a Plant.
   * @param organism the organism to be eaten, if the organism is only a Plant. Otherwise, it will not perform any "eat" logic.
   */
  public void eat(Organism organism) {
    if ( organism instanceof Plant ) {
      Plant plant = (Plant) organism;
      this.setHealth(getHealth() + plant.getHealth());
      plant.setHealth(0);
    }
  }
  
  /**
   * collide
   * The implementation of the "collide" function. It is functioning only if the animal is a Sheep.
   * It functions if both sheep have the current health equals to or is greater than the half of the spawnHealth. 
   * Both sheep will lose half of the initial sheep spawn health
   * A new MaleSheep or FemaleSheep will be created (with equal chances) with a spawnHealth nutritional value. 
   * @param animal the animal to collide with, if the animal is only a Sheep (MaleSheep or FemaleSheep) object. Otherwise, it will not perform any "collide" logic.
   * @return a new MaleSheep or FemaleSheep created (with equal chances) with a spawnHealth value as the result of the collision.
   */
  public Sheep collide(Animal animal) {
     if ( ( this instanceof MaleSheep && animal instanceof FemaleSheep ) ||
       ( this instanceof FemaleSheep && animal instanceof MaleSheep ) ) {
         Sheep theOtherSheep = (Sheep) animal;
         if ( this.getHealth() >= spawnHealth && theOtherSheep.getHealth() >= spawnHealth ) {
           this.setHealth(getHealth() - spawnHealth/2);
           theOtherSheep.setHealth(theOtherSheep.getHealth() - spawnHealth/2);
           if ( Math.random() < 0.5 ) {
             return new MaleSheep ( spawnHealth + 1, true );
           } else {
             return new FemaleSheep ( spawnHealth + 1, true );
           }
         }
       }
       return null;
  }
  
  /**
   * getImage
   * The image to be returned by Sheep's subclasses, i.e., MaleSheep or FemaleSheep, that is required by the 
   * draw() method to draw on the Grid.
   * @return Image the image that will be drawn on the Grid
   */
  public abstract Image getImage();
}