/*
 * MaleSheep
 * The concrete class that represents a male Sheep that can be placed in the ecosystem.
 * @author Alyssa Gao
 * May 3, 2018
 */

import java.awt.Image;
import java.awt.Toolkit;

public class MaleSheep extends Sheep {
  
  // ===================== VARIABLES ===================== 
  
  /**
   * The filename of the male sheep image.
   */
  public static String maleSheepImageFilename = "male sheep.png";
  
  /**
   * The Image object of the male sheep image.
   */
  public static Image maleSheepImage = Toolkit.getDefaultToolkit().getImage(maleSheepImageFilename);
  
  // ===================== CONSTRUCTORS =====================
  
  /**
   * The constructor of a MaleSheep object.
   * @param health the initial health of the MaleSheep to be created.
   */
  public MaleSheep(int health) {
    super(health);
  }
  
  /**
   * The constructor of a MaleSheep object.
   * @param health the initial health of the MaleSheep to be created.
   * @param setNewSpawnAge indicates whether or not to set the newSpawnAge to 3 (instead of 0 as the default value) through the constructor of the Sheep class, the Animal class and the Organism class.
   */
  public MaleSheep(int health, boolean setNewSpawnAge) {
    super(health, setNewSpawnAge);
  }
  
  //  ===================== METHODS =====================
  
  /**
   * getImage
   * it returns the baby sheep image if the newSpawnAge is greater than zero, for visual effects.
   * @return the image that will be invoked by Organism.draw() method to display the image of MaleSheep on the grid.
   */
  public Image getImage() {
    if ( getNewSpawnAge() > 0 ) {
      return babySheepImage;
    }else{
      return maleSheepImage;        
    }
  }  
}