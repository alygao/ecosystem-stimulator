/*
 * EcoSystem
 * A stimulation of an eco-system where user can input the size of ecosystem, number of organisms, health, and spawn rate
 * @author Alyssa Gao
 * May 3, 2018
 */

import java.awt.Point;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Scanner;
public class EcoSystem {
  
  /**
   * The number of steps up to which the EcoSystem will spawn plants at a rate of plantSpawnRate. Default to 5. It can be overwritten by user input.
   */
  public static int defaultMaxNumOfStepsToSpawnPlants = 5;
  
  /**
   * The default number of plants to be spawn within the EcoSystem at a random # of steps. Default to 150. It can be overwritten by user input. 
   */
  public static int defaultPlantSpawnRate = 150;
  
  /**
   * The default initial number of male sheep in the EcoSystem. Default to 100. It can be overwritten by user input.
   */
  public static int defaultIntialNumberOfMaleSheep = 100;
  
  /**
   * The default initial number of female sheep in the EcoSystem. Default to 100. It can be overwritten by user input.
   */
  public static int defaultIntialNumberOfFemaleSheep = 100;
  
  /**
   * The default initial number of male wolves in the EcoSystem. Default to 2. It can be overwritten by user input.
   */
  public static int defaultInitialNumberOfMaleWolves = 2;
  
  /**
   * The default initial number of female wolves in the EcoSystem. Default to 2. It can be overwritten by user input.
   */
  public static int defaultInitialNumberOfFemaleWolves = 2;
  
  /**
   * The default initial number of plants in the EcoSystem. Default to 200. It can be overwritten by user input.
   */
  public static int defaultInitialNumberOfPlants = 200;
  
  /**
   * The default nutrition value of all plants. Default to 15. It can be overwritten by user input.
   */
  public static int defaultPlantNutritionalValue = 15;
  
  /**
   * The default initial health of all sheep. Default to 20. It can be overwritten by user input.
   */
  public static int defaultSheepHeatlh = 30;
  
  /**
   * The default initial health of all wolves. Default to 10. It can be overwritten by user input.
   */
  public static int defaultWolfHealth = 10;
  
  /**
   * The default sheep spawn health. Default to 30. It can be overwritten by user input.
   */
  public static int defaultSheepSpawnHealth = 30;
  
  /**
   * The default wolf spawn health. Default to 10. It can be overwritten by user input.
   */
  public static int defaultWolfSpawnHealth = 10;

  /**
   * The default width of the grid. Default to 50. It can be overwritten by user input.
   */
  public static int defaultGridWidth = 50;
  
  /**
   * The default width of the grid. Default to 50. It can be overwritten by user input.
   */
  public static int defaultGridHeight = 50;
  
  /**
   * Random number generator used across the whole EcoSystem.
   */
  private static Random random = new Random ( );
  
  /**
   * The number of steps up to which the EcoSystem will spawn plants at a rate of plantSpawnRate, which is default to defaultMaxNumOfStepsToSpawnPlants.
   */  
  public static int maxNumOfStepsToSpawnPlants = defaultMaxNumOfStepsToSpawnPlants;
  
  /**
   * The number of plants to be spawn after a random # of steps. It takes the input from the user and defaults to defaultPlantSpawnRate.
   */
  public int plantSpawnRate = defaultPlantSpawnRate;
  
  /**
   * The initial number of male sheep in the EcoSystem. It takes the input from the user and defaults to defaultIntialNumberOfSheep.
   */
  public int initialNumberOfMaleSheep = defaultIntialNumberOfMaleSheep;
  
  /**
   * The initial number of female sheep in the EcoSystem. It takes the input from the user and defaults to defaultIntialNumberOfSheep.
   */
  public int initialNumberOfFemaleSheep = defaultIntialNumberOfFemaleSheep;
  
  /**
   * The initial number of male wolves in the EcoSystem. It takes the input from the user and defaults to defaultInitialNumberofMaleWolves.
   */
  public int initialNumberOfMaleWolves = defaultInitialNumberOfMaleWolves;
  
  /**
   * The initial number of female wolves in the EcoSystem. It takes the input from the user and defaults to defaultInitialNumberofFemaleWolves.
   */
  public int initialNumberOfFemaleWolves = defaultInitialNumberOfFemaleWolves;
  
  /**
   * The initial number of plants in the EcoSystem. It takes the input from the user and defaults to defaultInitialNumberofPlants.
   */
  public int initialNumberOfPlants = defaultInitialNumberOfPlants;
  
  /**
   * The nutrition value for constructing a new plant. It takes the input from the user and defaults to defaultPlantNutritionalValue.
   */
  public int plantNutritionalValue = defaultPlantNutritionalValue;
  
  /**
   * The initial health for constructing a new Sheep. It takes the input from the user and defaults to defaultSheepHeatlh.
   */
  public int sheepHealth = defaultSheepHeatlh;
  
  /**
   * The initial health for constructing a new Wolf. It takes the input from the user and defaults to defaultWolfHealth.
   */
  public int wolfHealth = defaultWolfHealth;
  
  /**
   * The initial health for constructing a spawn Sheep. It takes the input from the user and defaults to defaultSheepSpawnHealth.
   */
  public int sheepSpawnHealth = defaultSheepSpawnHealth;
  
  /**
   * The initial health for constructing a spawn Wolf. It takes the input from the user and defaults to defaultWolfSpawnHealth.
   */
  public int wolfSpawnHealth = defaultWolfSpawnHealth;
  
  /**
   * The width of the grid. It takes the input from the user and defaults to defaultGridWidth.
   */
  public int gridWidth = defaultGridWidth;
  
  /**
   * The height of the grid. It takes the input from the user and defaults to defaultGridHeight.
   */
  public int gridHeight = defaultGridHeight;
  
  /**
   * The 2D array of grids. Each grid holds a Sheep, Wolf, Plant or is an EmptyLand.  
   */
  public Grid[][] world;
  
  /**
   * A list that contains all empty land currently in the EcoSystem. 
   */
  List<EmptyLand> emptyLandList = new ArrayList<EmptyLand>();
  
  /**
   * A list that contains all male wolves currently in the EcoSystem. 
   */
  List<MaleWolf> maleWolfList = new ArrayList<MaleWolf>();
  
  /**
   * A list that contains all female wolves currently in the EcoSystem. 
   */
  List<FemaleWolf> femaleWolfList = new ArrayList<FemaleWolf>();
  
  /**
   * A list that contains all male sheep currently in the EcoSystem. 
   */
  List<MaleSheep> maleSheepList = new ArrayList<MaleSheep>();
  
  /**
   * A list that contains all female sheep currently in the EcoSystem. 
   */
  List<FemaleSheep> femaleSheepList = new ArrayList<FemaleSheep>();
  
  /**
   * A list that contains all plants currently in the EcoSystem. 
   */
  List<Plant> plantList = new ArrayList<Plant>();   
  
  // ===================== CONSTRUCTORS =====================
  
  /**
   * The constructor that performs two tasks:
   * (1) Prompts for inputing parameters
   * (2) Initializes the ecosystem. 
   */
  public EcoSystem ( ) {
    inputParameters();
    initializeWorld();
  }
  
  //  ===================== METHODS =====================
  
  public static void main(String[] args) {
    
    EcoSystem ecoSystem = new EcoSystem( );
      
    runEcoSystem(ecoSystem);
  }
  
  /**
   * The main function that runs to simulate the EcoSystem. It performs the following tasks:
   * (1) Initialize the DisplayGrid and invokes it in each turn.
   * (2) In each turn:
   *   (2.1) Move each animal (if it is possible). During the move, it handles the logic of eat, collide, spawn
   *   (2.2) Spawn new plants after random turns
   *   (2.3) Decrease all animals' health by 1.
   *   (2.4) Check for termination condition (There is no sheep, wolf or plant exists in the EcoSystem) 
   * @param ecoSystem an initialized EcoSystem object.
   */
  public static void runEcoSystem ( EcoSystem ecoSystem ) {
    int remainingStepsToSpawnPlants = random.nextInt(maxNumOfStepsToSpawnPlants);
    
    //Set up Grid Panel
    DisplayGrid displayGrid = new DisplayGrid(ecoSystem.world);
    
    boolean continueMoving = true;
    
    displayGrid.refresh();
    
    while ( continueMoving ) {
      
      ecoSystem.resetAllAnimalMoveFlags();
      
      ecoSystem.decreaseNewSpawnAge();
      
      sleep(1000);
      
      // Move all animals
      ecoSystem.moveAnimals ( );
      
      // spawn plants
      if ( remainingStepsToSpawnPlants == 0 ) {
        remainingStepsToSpawnPlants = random.nextInt(maxNumOfStepsToSpawnPlants);
        ecoSystem.spawnPlants ( );
      } else {
        remainingStepsToSpawnPlants --;
      }
      
      // check the termination condition - if anyone of the species is gone
      if ( ecoSystem.maleWolfList.size() + ecoSystem.femaleWolfList.size() == 0 || ecoSystem.maleSheepList.size() + ecoSystem.femaleSheepList.size() == 0 || ecoSystem.plantList.size() == 0 ) {
        System.out.println( "\nThere is no sheep, wolf or plant that exists in the EcoSystem, terminating the program." );
        continueMoving = false;
      }
      
      ecoSystem.decreaseOrganismHealth();
      
      displayGrid.refresh();
    }
  }
  
  /**
   * decreaseNewSpawnAge
   * Decrease the newSpawnAge of Plants or Sheep (MaleSheep or FemaleSheep) or Wolf (MaleWolf or FemaleWolf. 
   * This is used for controlling the display of new spawn plants/sheep/wolf pictures on DisplayGrid.
   * It is invoked in each turn in the runEcoSystem() method.
   */
  public void decreaseNewSpawnAge ( ) {
    for ( int i = 0; i < this.plantList.size(); i ++ ) {
      this.plantList.get(i).decreaseNewSpawnAge();
    }
    for ( int i = 0; i < this.maleSheepList.size(); i ++ ) {
      this.maleSheepList.get(i).decreaseNewSpawnAge();
    }
    for ( int i = 0; i < this.femaleSheepList.size(); i ++ ) {
      this.femaleSheepList.get(i).decreaseNewSpawnAge();
    }
    for ( int i = 0; i < this.maleWolfList.size(); i ++ ) {
      this.maleWolfList.get(i).decreaseNewSpawnAge();
    }
    for ( int i = 0; i < this.femaleWolfList.size(); i ++ ) {
      this.femaleWolfList.get(i).decreaseNewSpawnAge();
    }
  }
  
  /**
   * resetAllAnimalMoveFlags
   * In each turn, after an animal has moved, a flag is set in wolfList, maleSheepList or femaleSheepList.
   * At the beginning of each turn, all flags are reset in thsi method. This prevents an animal to move more than once in a single turn.
   */
  private void resetAllAnimalMoveFlags ( ) {
    for ( int i = 0; i < this.maleWolfList.size(); i ++ ) {
      this.maleWolfList.get(i).setAlreadyMovedInTheCurrentTurn( false );
    }
    for ( int i = 0; i < this.femaleWolfList.size(); i ++ ) {
        this.femaleWolfList.get(i).setAlreadyMovedInTheCurrentTurn( false );
      }
    for ( int i = 0; i < this.maleSheepList.size(); i ++ ) {
      this.maleSheepList.get(i).setAlreadyMovedInTheCurrentTurn( false );
    }
    for ( int i = 0; i < this.femaleSheepList.size(); i ++ ) {
      this.femaleSheepList.get(i).setAlreadyMovedInTheCurrentTurn( false );
    }
  }
  
  /**
   * decreaseOrganismHealth
   * This method is invoked at end of each turn to decrease all live animals' and plants' health.
   */
  private void decreaseOrganismHealth ( ) {
    for ( int i = this.maleWolfList.size() - 1; i >= 0 ; i -- ) {
      MaleWolf maleWolf = this.maleWolfList.get(i);
      boolean alive = maleWolf.decreaseHealth();
      if ( ! alive ) {
        removeOrganismIfNotAlive ( maleWolf.getCurrentPosition().x, maleWolf.getCurrentPosition().y );
      }
    }
    for ( int i = this.femaleWolfList.size() - 1; i >= 0 ; i -- ) {
        FemaleWolf femaleWolf = this.femaleWolfList.get(i);
        boolean alive = femaleWolf.decreaseHealth();
        if ( ! alive ) {
          removeOrganismIfNotAlive ( femaleWolf.getCurrentPosition().x, femaleWolf.getCurrentPosition().y );
        }
      }
    for ( int i = this.maleSheepList.size() - 1; i >= 0 ; i -- ) {
      MaleSheep maleSheep = this.maleSheepList.get(i);
      boolean alive = maleSheep.decreaseHealth();
      if ( ! alive ) {
        removeOrganismIfNotAlive ( maleSheep.getCurrentPosition().x, maleSheep.getCurrentPosition().y );
      }
    }
    for ( int i = this.femaleSheepList.size() - 1; i >= 0 ; i -- ) {
      FemaleSheep femaleSheep = this.femaleSheepList.get(i);
      boolean alive = femaleSheep.decreaseHealth();
      if ( ! alive ) {
        removeOrganismIfNotAlive ( femaleSheep.getCurrentPosition().x, femaleSheep.getCurrentPosition().y );
      }
    }
    for ( int i = this.plantList.size() - 1; i >= 0 ; i -- ) {
      Plant plant = this.plantList.get(i);
      boolean alive = plant.decreaseHealth();
      if ( ! alive ) {
        removeOrganismIfNotAlive ( plant.getCurrentPosition().x, plant.getCurrentPosition().y );
      }
    }
  }
  
  /**
   * sleep
   * A utility method to hang the program for a specific period
   * @param milliSecond milliseconds that elapses before continuing.
   */
  public static void sleep ( long milliSecond ) {
    try {
      Thread.sleep(milliSecond);
    } catch (InterruptedException e) { }
  }
  
  /**
   * spawnPlants
   * Spawn new plants after a random number of turns which is controlled in the runEcoSystem() method.
   * The number of new plants are indicated by the lesser number of plantSpawnRate variable (default to defaultPlantSpawnRate) and totalEmptyLandCount.
   * The new spawn plant will have a nutrition value specified by plantNutritionalValue variable, default to defaultPlantNutritionalValue.
   */
  public void spawnPlants ( ) {
    int totalPlantsToSpawn = Math.min ( plantSpawnRate, this.emptyLandList.size() ); 
    for ( int i = 0; i < totalPlantsToSpawn; i ++ ) {
      placeNewOrganism ( new Plant ( plantNutritionalValue, true ) );
    }
  }
  
  /**
   * moveAnimalToNewPositions
   * Move all animals within the ecosystem for a single turn. It handles the following moving scenarios:
   * 1) A wolf collides to another wolf
   * 2) A wolf eats a sheep
   * 3) A wolf moves to a plant
   * 4) A sheep moves and is eaten by a wolf
   * 5) A sheep collides with another sheep, possibly spawn a new sheep.
   * 6) A sheep eats a plant
   * 7) A move to an empty space
   */
  public void moveAnimals ( ) {        
    // move existing Animals randomly
    for ( int i = 0; i < gridHeight; i ++ ) {
      for ( int j = 0; j < gridWidth; j ++ ) {
        if ( world[i][j] instanceof Animal ) {
          if ( !((Animal)world[i][j]).isAlreadyMovedInTheCurrentTurn() ) {
            ((Animal)world[i][j]).setAlreadyMovedInTheCurrentTurn(true);
            Point newPosition = generateNextPosition ( i, j );
            
            if ( world[i][j] instanceof Wolf && world[newPosition.x][newPosition.y] instanceof Wolf ) { // wolf collide with wolf
              Wolf spawnWolf = ((Wolf)world[i][j]).collide ( (Wolf)world[newPosition.x][newPosition.y] );
              // no move when collide
              removeOrganismIfNotAlive ( i, j );
              removeOrganismIfNotAlive ( newPosition.x, newPosition.y );
              
              if ( spawnWolf != null ) {
                  placeNewOrganism ( spawnWolf );
              }
              
            } else if ( world[i][j] instanceof Wolf && world[newPosition.x][newPosition.y] instanceof Sheep ) {
              ((Wolf)world[i][j]).eat ( (Sheep)world[newPosition.x][newPosition.y] );
              // no move when collide
              removeOrganismIfNotAlive ( newPosition.x, newPosition.y );
              moveAnimalToNewPosition ( i, j, newPosition.x, newPosition.y );
              
            } else if ( world[i][j] instanceof Wolf && world[newPosition.x][newPosition.y] instanceof Plant ) {
              ((Plant)world[newPosition.x][newPosition.y]).setHealth(0);
              removeOrganismIfNotAlive ( newPosition.x, newPosition.y );
              moveAnimalToNewPosition ( i, j, newPosition.x, newPosition.y );
              
            } else if ( world[i][j] instanceof Sheep && world[newPosition.x][newPosition.y] instanceof Wolf ) {
              ((Wolf)world[newPosition.x][newPosition.y]).eat ( (Sheep)world[i][j] );
              removeOrganismIfNotAlive ( i, j );
              // no need to move as the Sheep is eaten by the Wolf.
              
            } else if ( (world[i][j] instanceof Sheep && world[newPosition.x][newPosition.y] instanceof Sheep)) {
              Sheep spawnSheep = ((Sheep)world[i][j]).collide ( (Sheep)world[newPosition.x][newPosition.y] );
              // no move when collide
              removeOrganismIfNotAlive ( i, j );
              removeOrganismIfNotAlive ( newPosition.x, newPosition.y );
              
              if ( spawnSheep != null ) {
                placeNewOrganism ( spawnSheep );
              }
              
            } else if ( world[i][j] instanceof Sheep && world[newPosition.x][newPosition.y] instanceof Plant ) {
              ((Sheep)world[i][j]).eat ( (Plant)world[newPosition.x][newPosition.y] );
              removeOrganismIfNotAlive ( newPosition.x, newPosition.y );
              moveAnimalToNewPosition ( i, j, newPosition.x, newPosition.y );
              
            } else if ( world[newPosition.x][newPosition.y] instanceof EmptyLand ){
              // move to the new position only if the new position is an EmptyLand
              moveAnimalToNewPosition ( i, j, newPosition.x, newPosition.y );
            }
          }
        }
      }
    }
  }
  
  /**
   * moveAnimalToNewPosition
   * Moves a single animal to from an existing position to a new position. The existing position will be filled
   * with a EmptyLand object. In addition, the animal's position recorded in itself object will also be updated.
   * @param currentPositionX the column of the current position
   * @param currentPositionY the row of the current position
   * @param newPositionX the column of the new position
   * @param newPositionY the row of the new position
   */
  private void moveAnimalToNewPosition ( int currentPositionX, int currentPositionY, int newPositionX, int newPositionY ) {
    world[currentPositionX][currentPositionY].setCurrentPosition(newPositionX, newPositionY);
    world[newPositionX][newPositionY].setCurrentPosition(currentPositionX, currentPositionY);
    // swap between two grids
    Grid tempGrid = world[newPositionX][newPositionY];
    world[newPositionX][newPositionY] = world[currentPositionX][currentPositionY];
    world[currentPositionX][currentPositionY] = tempGrid;
    // There is no need to increment the totalEmptyLandCount by 1, as the invocation to moveAnimalToNewPosition() is a result
    // of two cases: (1) A Wolf eats a Sheep; (2) A Sheep eats a Plant. 
    // In both cases, the removeOrganismIfNotAlive() is invoked, which has already increased the totalEmptyLandCount.
  }
  
  /**
   * removeOrganismIfNotAlive
   * Remove the Organism (wolf, sheep or plant) currently located at (x, y) that is no longer alive (health == 0 )
   * from the ecosystem as well as from the corresponding organism list (i.e., wolfList, maleSheepList, femaleSheepList 
   * or plantList) ( through removeOrganismFromList() method). Then replace the current location with an EmptyLand object.
   * @param row the row of the current location where the organism is to be removed.
   * @param col the column of the current location where the organism is to be removed.
   */
  private void removeOrganismIfNotAlive ( int row, int col ) {
    if ( ! ((Organism)world[row][col]).isAlive() ) {
      removeOrganismFromList ( (Organism) world[row][col] );
      world[row][col] = new EmptyLand ( );
      world[row][col].setCurrentPosition( row, col );
      this.emptyLandList.add( (EmptyLand)world[row][col] );
      }
  }
  
  /**
   * placeNewOrganism
   * Place an Organism at a random generated position of an EmptyLand.
   * In another words, replaces a randomly selected EmptyLand with the provided Organism object.
   * It also removes the replaced EmptyLand object from the emptyLandList.
   * @param organism The Organism to be placed in the ecosystem.
   */
  private void placeNewOrganism ( Organism organism ) {
    int numberOfEmptyLands = this.emptyLandList.size();
    if( numberOfEmptyLands > 0 ) {
      int nextEmptyLandIndex = random.nextInt( this.emptyLandList.size() );
      EmptyLand emptyLandToBeReplaced = this.emptyLandList.get(nextEmptyLandIndex);
      world[emptyLandToBeReplaced.getCurrentPosition().x][emptyLandToBeReplaced.getCurrentPosition().y] = organism;
      saveOrganism ( organism, emptyLandToBeReplaced.getCurrentPosition().x, emptyLandToBeReplaced.getCurrentPosition().y );
      this.emptyLandList.remove(nextEmptyLandIndex);
    }
  }
  
  /**
   * saveOrganism
   * Adds organism into array list
   * @param organism The organism (plant, sheep, wolf) to be added to the array list
   * @param positionX The row of the position
   * @param positionY The column of the position
   */
  private void saveOrganism ( Organism organism, int positionX, int positionY ) {
    organism.setCurrentPosition(positionX, positionY);
    if (organism instanceof MaleWolf) {
      this.maleWolfList.add((MaleWolf)organism);
    } else if (organism instanceof FemaleWolf) {
      this.femaleWolfList.add((FemaleWolf)organism);
    } else if (organism instanceof MaleSheep) {
      this.maleSheepList.add((MaleSheep)organism);
    } else if (organism instanceof FemaleSheep) {
      this.femaleSheepList.add((FemaleSheep)organism);
    } else if (organism instanceof Plant) {
      this.plantList.add((Plant)organism);
    }
  }
  
  /**
   * removeOrganismFromList
   * Remove the Organism (wolf, sheep or plant) from the corresponding organism list (i.e., wolfList, maleSheepList, 
   * femaleSheepList or plantList).
   * @param organism the Organism that is to be removed.
   */
  private void removeOrganismFromList ( Organism organism ) {
    if (organism instanceof MaleWolf) {
      this.maleWolfList.remove((MaleWolf)organism);
    } else if (organism instanceof FemaleWolf) {
      this.femaleWolfList.remove((FemaleWolf)organism);
    } else if (organism instanceof MaleSheep) {
      this.maleSheepList.remove((MaleSheep)organism);
    } else if (organism instanceof FemaleSheep) {
      this.femaleSheepList.remove((FemaleSheep)organism);
    } else if (organism instanceof Plant) {
      this.plantList.remove((Plant)organism);
    }
  }
  
  /**
   * generateNextPosition
   * Generates next position within the ecosystem to which move from the current location based on a randomly generated direction (i.e., Up, Down, Left or Right)
   * @param i the column of the current position
   * @param j the row of the current position
   * @return Point the location of the next position.
   */
  private Point generateNextPosition ( int i, int j ) {
    boolean retry = true;
    int direction;
    Point newPosition = null;
    while ( retry ) {
      direction = random.nextInt(4); // 0 - UP, 1 - DOWN, 2 - LEFT, 3 - RIGHT
      if ( direction == 0 && i > 0 ) {
        newPosition = new Point ( i-1, j );
        retry = false;
      } else if ( direction == 1 && i < gridHeight - 1) {
        newPosition = new Point ( i+1, j );
        retry = false;
      } else if ( direction == 2 && j > 0 ) {
        newPosition = new Point ( i, j-1 );
        retry = false;
      } else if ( direction == 3 && j < gridWidth - 1 ) {
        newPosition = new Point ( i, j+1 );
        retry = false;
      }
    }
    return newPosition;
  }
  
  /**
   * inputParameters
   * Prompts user for input parameters. Press "Enter" to accept the default value.
   * If input is invalid, user must retry and reinput a valid input to proceed. 
   */
  public void inputParameters ( ) {
    boolean retry = true;
    int emptySpaceLeft = 0;
    Scanner input = new Scanner ( System.in );
    System.out.println( "====================== ECOSYSTEM STIMULATOR ======================" );
    System.out.println( "Please enter system parameters:" );
    System.out.println ("The default values will provide the most realistic ecosystem possible (longest lasting).");
    System.out.println ("Press \"Enter\" to accept the default value.\n");
    gridWidth = readInput ( input, "Please enter the grid witdth (must be greater than 0, default to %d): ", gridWidth );
    gridHeight = readInput ( input, "Please enter the grid height (must be greater than 0, default to %d): ", gridHeight );
    maxNumOfStepsToSpawnPlants = readInput ( input, "Please enter the maximum number of steps needed before plants are spawn (must be greater than 0, default to %d): ", maxNumOfStepsToSpawnPlants );
    plantSpawnRate = readInput ( input, "Please enter the plant spawn rate (must be greater than 0, default to %d): ", plantSpawnRate );
    
    emptySpaceLeft = gridWidth * gridHeight;
    while ( retry ) {
      
      initialNumberOfMaleSheep = readInput ( input, "Please enter initial number of male sheep (must be between 1 and %d, default to %%d): ", emptySpaceLeft, initialNumberOfMaleSheep );
      if ( initialNumberOfMaleSheep <= emptySpaceLeft ) {
        retry = false;
      } else {
        System.out.println ( "Too many male sheep, as there is not enough space in the grid. Please retry again . . ." );
      }
    }
    
    retry = true;
    emptySpaceLeft = gridWidth * gridHeight - initialNumberOfMaleSheep;
    while ( retry ) {
      initialNumberOfFemaleSheep = readInput ( input, "Please enter initial number of female sheep (must be between 1 and %d, default to %%d): ", emptySpaceLeft, initialNumberOfFemaleSheep );
      if ( initialNumberOfFemaleSheep < emptySpaceLeft ) {
        retry = false;
      } else {
        System.out.println ( "Too many female sheep, as there is not enough space in the grid. Please retry again . . ." );
      }
    }
    
    retry = true;
    emptySpaceLeft = gridWidth * gridHeight - initialNumberOfMaleSheep - initialNumberOfFemaleSheep;
    while ( retry ) {
      initialNumberOfMaleWolves = readInput ( input, "Please enter initial number of male wolves (must be between 1 and %d, default to %%d): ", emptySpaceLeft, initialNumberOfMaleWolves );
      if ( initialNumberOfMaleWolves < emptySpaceLeft ) {
        retry = false;
      } else {
        System.out.println ( "Too many male wolves, as there is not enough space in the grid. Please retry again . . ." );
      }
    }
    
    retry = true;
    emptySpaceLeft = gridWidth * gridHeight - initialNumberOfMaleSheep - initialNumberOfFemaleSheep - initialNumberOfFemaleWolves;
    while ( retry ) {
      initialNumberOfFemaleWolves = readInput ( input, "Please enter initial number of female wolves (must be between 1 and %d, default to %%d): ", emptySpaceLeft, initialNumberOfFemaleWolves );
      if ( initialNumberOfFemaleWolves < emptySpaceLeft ) {
        retry = false;
      } else {
        System.out.println ( "Too many female wolves, as there is not enough space in the grid. Please retry again . . ." );
      }
    }
    
    retry = true;
    emptySpaceLeft = gridWidth * gridHeight - initialNumberOfMaleSheep - initialNumberOfFemaleSheep - initialNumberOfMaleWolves - initialNumberOfFemaleWolves;
    while ( retry ) {
      initialNumberOfPlants = readInput ( input, "Please enter initial number of plants (must be between 1 and %d, default to %%d): ", emptySpaceLeft, initialNumberOfPlants );
      if ( initialNumberOfPlants < emptySpaceLeft ) {
        retry = false;
      } else {
        System.out.println ( "Too many wolves, as there is not enough space in the grid. Please retry again . . ." );
      }
    }
    
    plantNutritionalValue = readInput ( input, "Please enter the nutritional value of each plant (must be greater than 0, default to %d): ", plantNutritionalValue );
    sheepHealth = readInput ( input, "Please enter the initial health of a sheep (must be greater than 0, default to %d): ", sheepHealth );
    wolfHealth = readInput ( input, "Please enter the initial health of a wolf (must be greater than 0, default to %d): ", wolfHealth );
    sheepSpawnHealth = readInput ( input, "Please enter the initial health of a spawn sheep (must be greater than 0, default to %d): ", sheepSpawnHealth );
    Sheep.spawnHealth = sheepSpawnHealth;
    wolfSpawnHealth = readInput ( input, "Please enter the initial health of a spawn wolf (must be greater than 0, default to %d): ", wolfSpawnHealth );
    Wolf.spawnHealth = wolfSpawnHealth;
  }
  
  /**
   * initializeWorld
   * Initialize the ecosystem (world[][]) of the EcoSystem. It initializes the following items:
   * (1) the ecosystem (world[][])
   * (2) wolfList
   * (3) maleSheepList
   * (4) femaleSheepList
   * (5) plantList
   * (6) totalEmptyLandCount
   * Then it invokes placeNewOrganism() method to place animals and plants in the ecosystem.
   */
  public void initializeWorld ( ) {
    
    world = new Grid[gridHeight][gridWidth];
    
    this.maleWolfList = new ArrayList<MaleWolf>();
    this.femaleWolfList = new ArrayList<FemaleWolf>();
    this.maleSheepList = new ArrayList<MaleSheep>();
    this.femaleSheepList = new ArrayList<FemaleSheep>();
    this.plantList = new ArrayList<Plant>();
    
    for ( int i = 0; i < world.length; i ++ ) {
      for ( int j = 0; j < world[i].length; j ++ ) {
        world[i][j] = new EmptyLand(); // empty space
        world[i][j].setCurrentPosition(i, j);
        this.emptyLandList.add((EmptyLand)world[i][j]);
      }
    }
    
    // Place male sheep randomly.
    for ( int i = 0; i < initialNumberOfMaleSheep; i ++ ) {
      placeNewOrganism ( new MaleSheep ( sheepHealth ) );
    }
    
    // Place female sheep randomly.
    for ( int i = 0; i < initialNumberOfFemaleSheep; i ++ ) {
      placeNewOrganism ( new FemaleSheep ( sheepHealth ) );
    }
    
    // Place male wolves randomly.
    for ( int i = 0; i < initialNumberOfMaleWolves; i ++ ) {
      placeNewOrganism ( new MaleWolf ( wolfHealth ) );
    }
    
    // Place male wolves randomly.
    for ( int i = 0; i < initialNumberOfFemaleWolves; i ++ ) {
      placeNewOrganism ( new FemaleWolf ( wolfHealth ) );
    }
    
    // Place plants randomly.
    for ( int i = 0; i < initialNumberOfPlants; i ++ ) {
      placeNewOrganism ( new Plant ( plantNutritionalValue ) );
    }
  }
  
  /**
   * generateRandomPosition
   * Generate a random position within the ecosystem
   * @return Point the position generated.
   */
  public Point generateRandomPosition ( ) {
    int position = random.nextInt( gridWidth * gridHeight );
    int positionX = position / gridWidth;
    int positionY = position % gridWidth;
    return new Point ( positionX, positionY );
  }
  
  /**
   * readInput
   * A Utility method that prompt user to input a parameter. It also does the basic validation to ensure the input value is a positive integer.
   * @param input a Scanner object which is used to take user input
   * @param prompt The prompt question presented to the user for input. It contains the meaning of the parameter and the valid range. 
   * @param defaultValue The default value if user press "Enter" directly (spaces are ignored)
   * @return int the value that user inputs.
   */
  public static int readInput ( Scanner input, String prompt, int defaultValue ) {
    int inputValue = 0;
    boolean retry = true;
    while ( retry ) {
      System.out.printf ( prompt, defaultValue );
      String inputValueString = input.nextLine();
      if ( inputValueString.trim().length() == 0 ) {
        // take the default value
        inputValue = defaultValue;
        retry = false;
      } else {
        try {
          inputValue = Integer.parseInt(inputValueString);
        } catch (NumberFormatException e) { 
          inputValue = 0;
        }
      }
      if ( inputValue > 0 ) {
        retry = false;
      } else {
        System.out.println( "Invalid input value, please retry . . ." );
      }
    }
    return inputValue; 
  }
  
  /**
   * readInput
   * A Utility method that prompt user to input a parameter. It also does the basic validation to ensure the input value
   * is a positive integer.
   * @param input a Scanner object which is used to take user input
   * @param prompt The prompt question presented to the user for input. It contains the meaning of the parameter.
   * @param criteriaValue used to render the prompt question that contain the maximum value that user can input.
   * @param defaultValue The default value if user press "Enter" directly (spaces are ignored)
   * @return int the value that user inputs.
   */
  public static int readInput ( Scanner input, String prompt, int criteriaValue, int defaultValue ) {
    return readInput ( input, prompt.format(prompt, criteriaValue), defaultValue);
  }
}