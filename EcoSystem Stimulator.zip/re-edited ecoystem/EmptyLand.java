/*
 * EmptyLand
 * The super class that represents an EmptyLand that can be placed in the ecosystem.
 * @author Alyssa Gao
 * May 3, 2018
 */

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Point;
import java.awt.image.ImageObserver;
public class EmptyLand extends Grid {
  
  // ===================== CONSTRUCTORS =====================
  
  /**
   * The default constructor.
   */
  public EmptyLand() { }
  
  //  ===================== METHODS =====================
  
  /**
   * draw
   * The implementation that draws the EmptyLand image on the grid of the ecosystem as a grey rectangle box with a black border.
   * @param g A Graphics object for drawing the image.
   * @param point the position where to draw the image.
   * @param gridToScreenRatio the grid-to-screen ratio, which is calculated in the DisplayGrid class.
   * @param observer The JPanel (where the grids are place) to be notified as more of the image is converted.
   */ 
  public void draw(Graphics g, Point point, int gridToScreenRatio, ImageObserver observer) {
    g.setColor(Color.LIGHT_GRAY ); // fill colour for empty land
    g.fillRect(point.x * gridToScreenRatio, point.y * gridToScreenRatio, gridToScreenRatio, gridToScreenRatio);
    g.setColor(Color.LIGHT_GRAY); // outline fo empty land
    g.drawRect(point.x * gridToScreenRatio, point.y * gridToScreenRatio, gridToScreenRatio, gridToScreenRatio);
  } 
}