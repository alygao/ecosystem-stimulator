/*
 * Grid
 * The super class that represents a "thing" that can be placed in the ecosystem. It could be a Wolf, a MaleSheep, a FemaleSheep, a Plant or an EmptyLand.
 * @author Alyssa Gao
 * May 3, 2018
 */

import java.awt.Graphics;
import java.awt.Point;
import java.awt.image.ImageObserver;

public abstract class Grid {
  
  // ===================== VARIABLES ===================== 
   
  /**
   * The column of the current position in the ecosystem (world[][]).
   */
  private int currentPositionX = 0;
  /**
   * The row of the current position in the ecosystem (world[][]).
   */
  private int currentPositionY = 0;
  
  // ===================== CONSTRUCTORS =====================
  
  /**
   * The default constructor.
   */
  public Grid() {
  }
  
  //  ===================== METHODS =====================
  
  /**
   * draw
   * Draw the image of the "thing" in the ecosystem. It is invoked by the DisplayGrid class and is expected to be implemented by sub classes.
   * @param g A Graphics object for drawing the image.
   * @param point the position where to draw the image.
   * @param gridToScreenRatio the grid-to-screen ratio, which is calculated in the DisplayGrid class.
   * @param observer The JPanel (where the grids are place) to be notified as more of the image is converted.
   */
  public abstract void draw ( Graphics g, Point point, int gridToScreenRatio, ImageObserver observer);
  
  /**
   * getCurrentPosition
   * @return the current position in the ecosystem 
   */
  public Point getCurrentPosition() {
    return new Point ( this.currentPositionX, this.currentPositionY );
  }
  
  /**
   * setCurrentPosition
   * Set the current position in the ecosystem.
   * @param currentPositionX The column of the current position.
   * @param currentPositionY The row of the current position.
   */
  public void setCurrentPosition(int currentPositionX, int currentPositionY ) {
    this.currentPositionX = currentPositionX;
    this.currentPositionY = currentPositionY;
  }
  
  /**
   * setCurrentPosition
   * Set the current position in the ecosystem.
   * @param currentPosition The current position to be set.
   */
  public void setCurrentPosition(Point currentPosition) {
    this.setCurrentPosition(currentPosition.x, currentPosition.y);
  }
}