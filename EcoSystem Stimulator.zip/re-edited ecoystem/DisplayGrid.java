/* 
 * DisplayGrid
 * The DisplayGrid class implements the functionality of displaying Grid objects (Organism objects and EmptyLand objects)on the JPanel.
 * @author Alyssa Gao
 * May 3, 2018
 */

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Point;
import java.awt.Toolkit;

// Graphics Imports
import javax.swing.JFrame;
import javax.swing.JPanel;

class DisplayGrid {
  
  /**
   * The GUI main window.
   */
  private JFrame frame;
  
  /**
   * The maximum x and y value of the screen. It is derived from the screen width and height, for the 
   * calculation of GridToScreenRatio. 
   */
  private int maxX, maxY;
  
  /**
   * The ratio for calculating the pixel coordinates based on the grid row and column.
   */
  private int GridToScreenRatio;
  
  /**
   * The ecosystem grids that is used for display on the JFrame/JPanel.
   */
  private Grid[][] world;
  
  /**
   * The constructor that takes the ecosystem (EcoSystem.world[][]) as the initial parameters. In this constructor,
   * the GridToScreenRatio will be calculated.
   * @param w the ecosystem that is going to be used for rendering the GUI.
   */
  DisplayGrid(Grid[][] w) {
    this.world = w;
    
    maxX = Toolkit.getDefaultToolkit().getScreenSize().width;
    maxY = Toolkit.getDefaultToolkit().getScreenSize().height;
    GridToScreenRatio = maxY / (world.length + 1); // ratio to fit in screen as square map
    
    System.out.println("Map size: " + world.length + " by " + world[0].length + "\nScreen size: " + maxX + "x" + maxY + " Ratio: " + GridToScreenRatio);
    
    this.frame = new JFrame("Ecosystem Stimulator");
    
    GridAreaPanel worldPanel = new GridAreaPanel();
    
    frame.getContentPane().add(BorderLayout.CENTER, worldPanel);
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    // frame.setSize(Toolkit.getDefaultToolkit().getScreenSize());
    frame.setSize(new Dimension((this.world[0].length + 1) * GridToScreenRatio,
                                (this.world.length + 2) * GridToScreenRatio));
    frame.setVisible(true);
  }
  
  /**
   * Terminate the JFrame and consequently the overall program.
   */
  public void terminate() {
    this.frame.dispose();
  }
  
  /**
   * Triggers the repaint or refresh of the GUI.
   */
  public void refresh() {
    frame.repaint();
  }
  
  /**
   * GridAreaPanel
   * Subclass of the JPanel that is mainly responsible for rendering the GUI.
   * @author Alyssa Gao
   * May 3, 2018
   */
  class GridAreaPanel extends JPanel {
    
    /**
     * Renders all Organism and EmptyLand objects on the GUI. It delegates the "draw" function to each
     * individual classes, i.e., EmptyLand, Wolf, Sheep (MaleSheep/FemaleSheep) and Plant. 
     */
    public void paintComponent(Graphics g) {
      // super.repaint();
      
      setDoubleBuffered(true);
      g.setColor(Color.BLACK);
      
      for (int x = 0; x < world.length; x++) {
        for (int y = 0; y < world[0].length; y++) {
          world[x][y].draw(g, new Point(x, y), GridToScreenRatio, this);
        }
      }
    }
  }
} 