/*
 * Organism
 * The super class that represents an organism that can be placed in the ecosystem. It could be a Wolf, a MaleSheep, a FemaleSheep, a Plant.
 * @author Alyssa Gao
 * May 3, 2018
 */

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Point;
import java.awt.image.ImageObserver;

public abstract class Organism extends Grid {
  
  // ===================== VARIABLES ===================== 
   
  /**
   * The health count of the Organism (wolves, sheep or plants).
   * For plants, it is used for the nutrition value.
   */
  private int health;
  
  /**
   * The age of a new spawn organism. It is defined for visual effects only.
   * And it is defined for sheep and plants 
   */
  private int newSpawnAge = 0;
  
  /**
   * Number of health to lose per each turn, default to 1.
   */
  public static int healthLostEachTurn = 1;
  
  // ===================== CONSTRUCTORS =====================
  
  /**
   * The constructor of an Organism object.
   * @param health the initial health of the Organism to be created.
   */
  public Organism ( int health ) {
    this.health = health;
  }
  
  /**
   * The constructor of an Organism object.
   * @param health the initial health of the Organism to be created.
   * @param setNewSpawnAge indicates whether or not to set the newSpawnAge to 3 (instead of 0 as the default value). 
   */
  public Organism ( int health, boolean setNewSpawnAge ) {
    this ( health );
    if ( setNewSpawnAge ) {
      this.newSpawnAge = 3;
    }
  }
  
  //  ===================== METHODS =====================
  
  /**
   * Returns the health value
   * @return the health value
   */
  public int getHealth() {
    return health;
  }
  
  /**
   * Set the health value
   * @param health the health value to be set.
   */
  public void setHealth(int health) {
    this.health = health;
  }
  
  
  /**
   * decreaseHealth
   * Decrease animal's health by 1.
   * @return true if the animal is still alive (health > 0), otherwise if it is dead (health == 0)
   */
  public boolean decreaseHealth() {
    int health = getHealth();
    if (health > 0) {
      setHealth(health - healthLostEachTurn);
    }
    return isAlive();
  }
  
  
  /**
   * isAlive
   * Indicates whether the Organism is still alive, i.e., the health is greater than zero.
   * @return true if the Organism is still alive (i.e., the health is greater than zero), otherwise false if it is dead.
   */
  public boolean isAlive ( ) {
    return this.health > 0;
  }
  
  /**
   * draw
   * The implementation that draws the Organism image on the grid of the ecosystem.
   * It depends on the abstract getImage() method that is expected to be implemented by the individual concrete subclasses (i.e., Wolf, MaleSheep, FemaleSheep and Plants) to obtain the actual images.
   * @param g A Graphics object for drawing the image.
   * @param point the position where to draw the image.
   * @param gridToScreenRatio the grid-to-screen ratio, which is calculated in the DisplayGrid class.
   * @param observer The JPanel (where the grids are place) to be notified as more of the image is converted.
   */
  public void draw(Graphics g, Point point, int gridToScreenRatio, ImageObserver observer) {
    g.drawImage ( getImage(), point.x * gridToScreenRatio, point.y * gridToScreenRatio, gridToScreenRatio, gridToScreenRatio, observer);
    g.setColor(Color.LIGHT_GRAY);
    g.drawRect ( point.x * gridToScreenRatio, point.y * gridToScreenRatio, gridToScreenRatio, gridToScreenRatio );
  }
  
  /**
   * getImage
   * The image to be returned by Organism's subclasses that is required by the draw() method to draw on the Grid.
   * @return Image the image that will be displayed on the Grid
   */
  public abstract Image getImage ( );
  
  /**
   * getNewSpawnAge
   * Returns the new spawn age.
   * @return the new spawn age.
   */
  public int getNewSpawnAge() {
    return newSpawnAge;
  }
  
  /**
   * setNewSpawnAge
   * Set the new spawn age.
   * @param newSpawnAge the new spawn age.
   */
  public void setNewSpawnAge(int newSpawnAge) {
    this.newSpawnAge = newSpawnAge;
  }
  
  /**
   * decreaseNewSpawnAge
   * Decrease the new spawn age by 1, if the new spawn age is greater than zero.
   */
  public void decreaseNewSpawnAge ( ) {
    if ( this.newSpawnAge > 0 ) {
      this.newSpawnAge --;
    }
  }
}