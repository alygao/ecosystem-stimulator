/*
 * Plant
 * The concrete class that represents a Plant that can be placed in the ecosystem.
 * @author Alyssa Gao
 * May 3, 2018
 */

import java.awt.Graphics;
import java.awt.Image;
import java.awt.Point;
import java.awt.Toolkit;
import java.awt.image.ImageObserver;

public class Plant extends Organism {
  
  // ===================== VARIABLES ===================== 
  
  /**
   * The filename of a regular plant image.
   */
  public static String plantImageFilename = "plant.png";
  /**
   * The Image object of a regular plant image.
   */
  public static Image plantImage = Toolkit.getDefaultToolkit().getImage(plantImageFilename);
  
  /**
   * The filename of a new spawn plant image.
   */
  public static String plantNewSpawnImageFilename = "plant-spawn.gif";
  /**
   * The Image object of a new spawn plant image.
   */
  public static Image plantNewSpawnImage = Toolkit.getDefaultToolkit().getImage(plantNewSpawnImageFilename);
  
  /**
   * The filename of a dying plant image that has a health value between 3 and 7.
   */
  public static String dyingPlantFilename =  "dying plant.png";
  /**
   * The Image object of a dying plant image.
   */
  public static Image dyingPlantImage = Toolkit.getDefaultToolkit().getImage(dyingPlantFilename);
  
  /**
   * The filename of an almost dead plant image that has a health value less than 3.
   */
  public static String almostDeadPlantFilename = "almost dead plant.png";
  /**
   * The Image object of an almost dead plant image.
   */
  public static Image almostDeadPlant = Toolkit.getDefaultToolkit().getImage(almostDeadPlantFilename);
  
  // ===================== CONSTRUCTORS =====================
  
  /**
   * The constructor of a Plant object.
   * @param nutritionalValue the initial health (nutritional value) of the Plant to be created.
   */
  public Plant ( int nutritionalValue ) {
    super(nutritionalValue );
  }
  
  /**
   * The constructor of a Plant object.
   * @param nutritionalValue the initial health (nutritional value) of the Plant to be created.
   * @param setNewSpawnAge indicates whether or not to set the newSpawnAge to 3 (instead of 0 as the default value) through the constructor of the Organism class.
   */
  public Plant(int nutritionalValue, boolean setNewSpawnAge) {
    super(nutritionalValue, setNewSpawnAge);
  }
  
  //  ===================== METHODS =====================
  
  /**
   * getImage
   * Returns the image that will be invoked by Organism.draw() method to display the image of Plant on the grid.
   * Depending on the health value, a regular plant image, a dying plant image or an almost dead plant image will be returned.
   * @return the image that will be invoked by Organism.draw() method to display the image of Wolf on the grid.
   */
  public Image getImage() {
    if ( getHealth() >= 8 ) {
      return plantImage;
    }else if ( getHealth() >= 3) {
      return dyingPlantImage;
    }else{
      return almostDeadPlant;
    }
  }
  
  /**
   * draw
   * It extends the draw() method defined in the super class, Organism, to add visual effects on top of the plant image to indicate a new spawn plant.
   * @param g A Graphics object for drawing the image.
   * @param point the position where to draw the image.
   * @param gridToScreenRatio the grid-to-screen ratio, which is calculated in the DisplayGrid class.
   * @param observer The JPanel (where the grids are place) to be notified as more of the image is converted.
   */
  public void draw(Graphics g, Point point, int gridToScreenRatio, ImageObserver observer) {
    super.draw(g, point, gridToScreenRatio, observer);
    if ( getNewSpawnAge() > 0  ) {
      g.drawImage ( plantNewSpawnImage, point.x * gridToScreenRatio, point.y * gridToScreenRatio, gridToScreenRatio, gridToScreenRatio, observer);
    }
  }    
}