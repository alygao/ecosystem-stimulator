/*
 * FemaleWolf
 * The concrete class that represents a female Wolf that can be placed in the ecosystem.
 * @author Alyssa Gao
 * May 3, 2018
 */

import java.awt.Image;
import java.awt.Toolkit;

public class FemaleWolf extends Wolf {
  
  // ===================== VARIABLES ===================== 
  
  /**
   * The filename of the female wolf image.
   */
  public static String femaleWolfImageFilename = "female wolf.png";
  
  /**
   * The Image object of the female wolf image.
   */
  public static Image femaleWolfImage = Toolkit.getDefaultToolkit().getImage(femaleWolfImageFilename);
  
  // ===================== CONSTRUCTORS =====================
  
  /**
   * The constructor of a FemaleWolf object.
   * @param health the initial health of the FemaleWolf to be created.
   */
  public FemaleWolf(int health) {
    super(health);
  }
  
  /**
   * The constructor of a FemaleWolf object.
   * @param health the initial health of the FemaleWolf to be created.
   * @param setNewSpawnAge indicates whether or not to set the newSpawnAge to 3 (instead of 0 as the default value) through the constructor of the Wolf class, the Animal class and the Organism class.
   */
  public FemaleWolf(int health, boolean setNewSpawnAge) {
    super(health, setNewSpawnAge);
  }
  
  //  ===================== METHODS =====================
  
  /**
   * getGenderVersionImage
   * @return femaleWolfImage, the graphic image for a female wolf
   */
  public Image getGenderVersionImage () {
   return femaleWolfImage;        
  }  
} 